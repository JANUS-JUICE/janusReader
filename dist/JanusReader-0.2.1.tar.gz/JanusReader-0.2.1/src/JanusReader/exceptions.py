class NOT_VALID_VICAR_FILE(Exception):
    """The input file is not ion VICAR format.
    """
    pass
