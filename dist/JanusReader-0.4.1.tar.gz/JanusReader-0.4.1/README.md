# JanusReader

**janusReader** is the offical Python library to read data coming from JANUS instrument on-board the ESA mission JUICE.

## Usage

```python
from JanusReader import JanusReader as JR

dat = JR("datafile.vic")

```